package usama.utech.wallpaperapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

import usama.utech.wallpaperapp.Adapter.ImageLoadAdapter;
import usama.utech.wallpaperapp.Model.ImageModelClass;

public class HomeScreen extends AppCompatActivity {

    RecyclerView recyclerView;
    ImageLoadAdapter imageLoadAdapter;
    ArrayList<ImageModelClass> imageModelClassArrayList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);





    }
}
