package usama.utech.wallpaperapp.Comman;

public class Comman {


    public static final String wallpaper_refrence = "Wallpapers" ;

}
