package usama.utech.wallpaperapp;

        import androidx.appcompat.app.AppCompatActivity;

        import android.os.Bundle;

public class ShowLargeImageWithDetailsAndOptions extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.show_image_with_large_details_activity);



    }
}
